import java.util.ArrayList;
import java.util.Vector;

/**
 * Classe unica per memorizzare tutti i nodi dell'XML
 * @author Axel Mastroianni Matteo Terzi Moussa
 * @version 1.0
 *
 */

public class Nodo {
	private String dato1=""; //credo 10 dati, il massimo numero che posso leggere dai 6 file
	private String dato2=""; //xml che ci sono stati inviati
	private String dato3="";
	private String dato4="";
	private String dato5="";
	private String dato6="";
	private String dato7="";
	private String dato8="";
	private String dato9="";
	private String dato10="";
	private int maxNumeroNodi=0;
	private Vector<Nodo> nodi=new Vector<Nodo>(); //la lista di nodi
	private Vector<String> dati; //sar� proveniente dalla classe Read
	public Nodo(Vector<String> dati, int maxNumeroNodi) { //costruttore del main
		this.dati=dati;
		this.maxNumeroNodi=maxNumeroNodi;
	}
	
	public Nodo(int maxNumeroNodi) { //costruttore del metodo getNodo
		this.maxNumeroNodi=maxNumeroNodi;
	}
	/** 
	 * questo metodo mi inizializza un nodo andando a prelevare i dati dall'ArrayList
	*proveniente dalla classe Read. Qui si suppone un massimo numero di nodi pari a 10
	*che � quello del file calendar
	 * @param partenza
	 * @return n oggetto di tipo Nodo
	 */
	public Nodo getNodo(int partenza) {
		Nodo n=new Nodo(maxNumeroNodi);
		for(int i=partenza;i<partenza+maxNumeroNodi;i++) {
			int analizza=i%maxNumeroNodi;//so che dato inizializzare
			if(i!=dati.size()-1) {
				switch(analizza) {
				case 0: n.setDato1(dati.get(i)); break; //inizializzo il primo dato
				case 1: n.setDato2(dati.get(i)); break; //inizializzo il secondo dato
				case 2: n.setDato3(dati.get(i)); break;
				case 3: n.setDato4(dati.get(i)); break;
				case 4: n.setDato5(dati.get(i)); break;
				case 5: n.setDato6(dati.get(i)); break;
				case 6: n.setDato7(dati.get(i)); break;
				case 7: n.setDato8(dati.get(i)); break;
				case 8: n.setDato9(dati.get(i)); break;
				case 9: n.setDato10(dati.get(i)); break;
				default: break;
				}
			}
			else
				return null;
		}
		return n;
	}
	/**
	 * riempio l'ArrayList dei nodi. Importante: la j si incrementa di maxNumeroNodi
	 * perch� cos� prendo ogni volta il tag iniziale che mi interessa
	 * @param niente
	 * @return niente
	 * 
	 */
	public void setNodi() {
		for(int j=0;j<dati.size();j+=maxNumeroNodi) { 
			nodi.add(getNodo(j)); //riempio l'ArrayList di nodi
		}
		System.out.println("Array riempito correttamente");
	}
	//metodo che verifica che la stampa sia corretta
	public void stampaNodi() {
		for(int i=0;i<nodi.size();i++)
			System.out.println(nodi.get(i).getDato1());
	}
	//getters e setters
	public String getDato1() {
		return dato1;
	}

	public void setDato1(String dato1) {
		this.dato1 = dato1;
	}

	public String getDato2() {
		return dato2;
	}

	public void setDato2(String dato2) {
		this.dato2 = dato2;
	}

	public String getDato3() {
		return dato3;
	}

	public void setDato3(String dato3) {
		this.dato3 = dato3;
	}

	public String getDato4() {
		return dato4;
	}

	public void setDato4(String dato4) {
		this.dato4 = dato4;
	}

	public String getDato5() {
		return dato5;
	}

	public void setDato5(String dato5) {
		this.dato5 = dato5;
	}

	public String getDato6() {
		return dato6;
	}

	public void setDato6(String dato6) {
		this.dato6 = dato6;
	}

	public String getDato7() {
		return dato7;
	}

	public void setDato7(String dato7) {
		this.dato7 = dato7;
	}

	public String getDato8() {
		return dato8;
	}

	public void setDato8(String dato8) {
		this.dato8 = dato8;
	}

	public String getDato9() {
		return dato9;
	}

	public void setDato9(String dato9) {
		this.dato9 = dato9;
	}

	public String getDato10() {
		return dato10;
	}

	public void setDato10(String dato10) {
		this.dato10 = dato10;
	}

	public int getMaxNumeroNodi() {
		return maxNumeroNodi;
	}

	public void setMaxNumeroNodi(int maxNumeroNodi) {
		if(maxNumeroNodi>0)
			this.maxNumeroNodi = maxNumeroNodi;
		else
			System.out.println("Errore, numero di nodi negativo");
	}

	public Vector<String> getDati() {
		return dati;
	}
	public Vector<Nodo> getNodi(){
		return nodi;
	}

}
