import it.unibs.fp.mylib.MyMenu;
import it.unibs.fp.mylib.Read;

public class Prova {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Read r=new Read();
		String[] menu= {"Scrivi modello XML standard","Filtra solo calendar_dates"};
		MyMenu ilMioMenu=new MyMenu("Scegli cosa fare",menu);
		//parte la memorizzazione dei dati
		//primo file
		r.esploraEMemorizza("./src/calendar_dates.xml");
		Nodo dates=new Nodo(r.getDati(),3);
		dates.setNodi();
		r.pulisciDati(); //svuoto sempre l'ArrayList in modo da riempirla con nuovi dati
		//secondo file
		r.esploraEMemorizza("./src/calendar.xml");
		Nodo calendar=new Nodo(r.getDati(),10);
		calendar.setNodi();
		r.pulisciDati();
		//terzo file
		r.esploraEMemorizza("./src/routes.xml");
		Nodo routes=new Nodo(r.getDati(),9);
		routes.setNodi();
		r.pulisciDati();
		//quarto file
		r.esploraEMemorizza("./src/stop_times.xml");
		Nodo times=new Nodo(r.getDati(),9);
		times.setNodi();
		r.pulisciDati();
		//quinto file
		r.esploraEMemorizza("./src/stops.xml");
		Nodo stops=new Nodo(r.getDati(),9);
		stops.setNodi();
		r.pulisciDati();
		//sesto file
		r.esploraEMemorizza("./src/trips.xml");
		Nodo trips=new Nodo(r.getDati(),8);
		trips.setNodi();
		r.pulisciDati();
		//per capire quale sia la lista di nodi pi� corta, titolo informativo
		System.out.println(dates.getNodi().size());
		System.out.println(trips.getNodi().size());
		System.out.println(times.getNodi().size());
		System.out.println(routes.getNodi().size());
		ScriviXML scrivi=new ScriviXML();
		int scelta=ilMioMenu.scegli();
		//in base alla voce che hai scelto nel men�
		switch(scelta) {
		case 1: scrivi.scriviDocumentoStandard(dates.getNodi(), trips.getNodi(),
			times.getNodi(),routes.getNodi(), "successo"); break; //prima consegna
			//seconda consegna
		case 2: scrivi.scriviSecondoModello(dates.getNodi(), "secondo successo"); break;
		}
		
	}

}
