import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Vector;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

public class ScriviXML {
	/**
	 * Questa classe scrive il modello XML sulla base di quanto scritto nella classe Write
	 * @author Axel Mastroianni Matteo Terzi Moussa(non so il nome intero)
	 * @version 1.0
	 */
	//Javadoc del metodo
	/**
	 * 
	 * @param dates Vector Nodo
	 * @param trips Vector Nodo
	 * @param times Vector Nodo
	 * @param routes Vector Nodo
	 * @param nomeDocumento
	 * @return true or false la scrittura ha avuto successo?
	 */
	public boolean scriviDocumentoStandard(Vector<Nodo>dates,Vector<Nodo>trips,
			Vector<Nodo>times,Vector<Nodo>routes,String nomeDocumento) {
		System.out.println("Scrittura su file");
		XMLOutputFactory output = XMLOutputFactory.newInstance();
		XMLStreamWriter writer;
		try {
			writer = output.createXMLStreamWriter(new FileWriter(nomeDocumento));
			writer.writeComment("data saved");
			writer.writeStartElement("serviziVari");
			//uso la lista pi� corta per evitare errori di NullPointer
			for(int i=0;i<routes.size()-1;i++) {
				writer.writeStartElement("services");
				writer.writeStartElement("date");
				writer.writeAttribute("id", dates.get(i).getDato1());
				writer.writeStartElement("trip");
				writer.writeAttribute("id", trips.get(i).getDato2());
				writer.writeStartElement("stop");
				writer.writeAttribute("id", times.get(i).getDato7());
				writer.writeStartElement("arrival");
				writer.writeAttribute("value", times.get(i).getDato3()); writer.writeEndElement();
				writer.writeStartElement("departures");
				writer.writeAttribute("value", times.get(i).getDato8()); writer.writeEndElement();
				writer.writeEndElement();
				writer.writeEndElement();
				writer.writeStartElement("route");
				writer.writeAttribute("id", routes.get(i).getDato1());
				writer.writeStartElement("longname");
				writer.writeAttribute("value", routes.get(i).getDato2()); writer.writeEndElement();
				writer.writeEndElement();
				writer.writeEndElement();
				writer.writeEndElement();
			}
			writer.writeEndDocument();
			writer.flush();
			writer.close();
			System.out.println("Scrittura avvenuta con successo");
		}catch(Exception e) {
			System.out.println("Si � verificato un problema");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	/**
	 * 
	 * @param dates Vector Nodo
	 * @param nomeDocumento
	 * @return true or false la scrittura ha avuto successo oppure no?
	 */
	public boolean scriviSecondoModello(Vector<Nodo> dates,String nomeDocumento) {
		System.out.println("Scrittura su file");
		XMLOutputFactory output = XMLOutputFactory.newInstance();
		XMLStreamWriter writer;
		try {
			writer = output.createXMLStreamWriter(new FileWriter(nomeDocumento));
			writer.writeComment("data saved");
			writer.writeStartElement("serviziVari");
			for(int i=0;i<dates.size()-1;i++) {
				writer.writeStartElement("date");
				writer.writeCharacters(dates.get(i).getDato1());
				writer.writeStartElement("service_id");
				writer.writeCharacters(dates.get(i).getDato2());
				writer.writeStartElement("exception_type");
				writer.writeCharacters(dates.get(i).getDato3());
				writer.writeEndElement();
				writer.writeEndElement();
				writer.writeEndElement();
			}
			writer.writeEndDocument();
			writer.flush();
			writer.close();
			System.out.println("Scrittura secondo file avvenuta con successo!");
		}catch(Exception e) {
			System.out.println("Si � verificato un problema");
			e.printStackTrace();
			return false;
		}
		return true;
	}

}
